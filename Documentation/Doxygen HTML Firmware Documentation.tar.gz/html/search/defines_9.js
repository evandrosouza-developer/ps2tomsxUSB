var searchData=
[
  ['kana_5fexti_0',['KANA_exti',['../system_8h.html#a08f80ac4b4fcf28aae3983feafd0f9bd',1,'system.h']]],
  ['kana_5fpin_1',['KANA_PIN',['../system_8h.html#a725cc9e2f31b9338bca6748846a615a4',1,'system.h']]],
  ['kana_5fport_2',['KANA_PORT',['../system_8h.html#a20d1458d9b483309565c97f15407ef52',1,'system.h']]],
  ['kb_5facknowledge_3',['KB_ACKNOWLEDGE',['../ps2handl_8c.html#a4313b4f2f9f9808fca38c53d77e811d4',1,'ps2handl.c']]],
  ['kb_5ferror_5fbat_4',['KB_ERROR_BAT',['../ps2handl_8c.html#a10f9483f089144b98ee98f50d7a12664',1,'ps2handl.c']]],
  ['kb_5ffirst_5fid_5',['KB_FIRST_ID',['../ps2handl_8c.html#a655be35ccbaa0c826f12c49eb545a7c6',1,'ps2handl.c']]],
  ['kb_5fsecond_5fid_6',['KB_SECOND_ID',['../ps2handl_8c.html#a2ca3d44507e4157b53a59abf915384e0',1,'ps2handl.c']]],
  ['kb_5fsuccessfull_5fbat_7',['KB_SUCCESSFULL_BAT',['../ps2handl_8c.html#a84f8523b86a340097989b86c38da57fb',1,'ps2handl.c']]],
  ['kbcomm_5fresend_8',['KBCOMM_RESEND',['../ps2handl_8c.html#afe708a0a24b5d6c79fb29b903cc695a6',1,'ps2handl.c']]]
];
