var searchData=
[
  ['_5f_5fattribute_5f_5f_0',['__attribute__',['../database_8c.html#abde056554f7359992fdf374b7f749269',1,'database.c']]],
  ['_5fclose_1',['_close',['../newlib__warning__fix_8c.html#a89d03692881c98197f1168cfe274d3f6',1,'_close():&#160;newlib_warning_fix.c'],['../newlib__warning__fix_8h.html#a036bc49a9f14455741940369aa888368',1,'_close(void):&#160;newlib_warning_fix.c']]],
  ['_5febss_2',['_ebss',['../ps2handl_8c.html#a907f7f11c56224811743271c0d9b0101',1,'ps2handl.c']]],
  ['_5fgetpid_3',['_getpid',['../newlib__warning__fix_8c.html#af7d8308a3080c4f341abe2237594167e',1,'_getpid():&#160;newlib_warning_fix.c'],['../newlib__warning__fix_8h.html#a77c2639bd5388a6f48e28b3660efa0ca',1,'_getpid(void):&#160;newlib_warning_fix.c']]],
  ['_5fkill_4',['_kill',['../newlib__warning__fix_8c.html#ae4f4984cff982459b6a165f56e86a1cb',1,'_kill():&#160;newlib_warning_fix.c'],['../newlib__warning__fix_8h.html#ae47169369e6a23386a0d453c8b728f06',1,'_kill(void):&#160;newlib_warning_fix.c']]],
  ['_5flseek_5',['_lseek',['../newlib__warning__fix_8c.html#ab3fca177137328e6e5d0552bea072a4d',1,'_lseek():&#160;newlib_warning_fix.c'],['../newlib__warning__fix_8h.html#aadb3a0af49d99b79debcee40c9d48127',1,'_lseek(void):&#160;newlib_warning_fix.c']]],
  ['_5fread_6',['_read',['../newlib__warning__fix_8c.html#a18b19ea19599213612131fc601786064',1,'_read():&#160;newlib_warning_fix.c'],['../newlib__warning__fix_8h.html#a12e573b08cd62fa793c682783eb2a6b1',1,'_read(void):&#160;newlib_warning_fix.c']]],
  ['_5fwrite_7',['_write',['../serial_8c.html#aa025a12d45f60c7d0eae249e61f0c7f9',1,'_write(int file, char *ptr, int len):&#160;serial.c'],['../serial_8h.html#aa025a12d45f60c7d0eae249e61f0c7f9',1,'_write(int file, char *ptr, int len):&#160;serial.c']]]
];
