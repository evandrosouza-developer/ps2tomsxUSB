var searchData=
[
  ['newlib_5fwarning_5ffix_2ec_0',['newlib_warning_fix.c',['../newlib__warning__fix_8c.html',1,'']]],
  ['newlib_5fwarning_5ffix_2eh_1',['newlib_warning_fix.h',['../newlib__warning__fix_8h.html',1,'']]]
];
