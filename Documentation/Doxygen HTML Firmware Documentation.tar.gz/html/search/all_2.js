var searchData=
[
  ['base_5fof_5fdatabase_0',['base_of_database',['../dbasemgt_8c.html#adc15948440d15f8d0d7c8349b50540b4',1,'base_of_database():&#160;msxmap.cpp'],['../get__intelhex_8c.html#adc15948440d15f8d0d7c8349b50540b4',1,'base_of_database():&#160;msxmap.cpp'],['../msxmap_8cpp.html#a08b24d97cda105bac6a3e3ca38f2112c',1,'base_of_database():&#160;msxmap.cpp']]],
  ['base_5fring_5fbuffer_5fsize_1',['BASE_RING_BUFFER_SIZE',['../system_8h.html#aaa991f7d0fe0a15baf96c8988bfcd564',1,'system.h']]],
  ['base_5fring_5fbuffer_5fsz_5fpower_2',['BASE_RING_BUFFER_SZ_POWER',['../system_8h.html#aabd5f6a9cb3b50d58cb276818c5cf792',1,'system.h']]],
  ['board_5fident_3',['BOARD_IDENT',['../usb__descriptors_8h.html#a209aaee6e9cf4f39cb1f575819284e6e',1,'usb_descriptors.h']]],
  ['bootmagic0_4',['BOOTMAGIC0',['../system_8h.html#aefe64de225ab9f9ed0f98e17adf34679',1,'system.h']]],
  ['bootmagic1_5',['BOOTMAGIC1',['../system_8h.html#a9c7d020f7c05c18952aec4b920d4a273',1,'system.h']]],
  ['buf_5fdma_5frx_6',['buf_dma_rx',['../serial_8c.html#af02d9f5207c626b542d5e8c6423e73e7',1,'serial.c']]],
  ['bufszmask_7',['bufSzMask',['../structs__pascal__string.html#a0b5b7a3d67ef63f72e764fbd6ac36297',1,'s_pascal_string::bufSzMask()'],['../structsring.html#a644560aad45670bb7554bd47af34aacb',1,'sring::bufSzMask()']]],
  ['bus_5ffault_5fhandler_8',['bus_fault_handler',['../SpecialFaultHandlers_8c.html#af4d707547ba21a4d3d8736ee61596793',1,'SpecialFaultHandlers.c']]]
];
