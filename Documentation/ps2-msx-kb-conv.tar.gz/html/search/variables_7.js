var searchData=
[
  ['get_5fptr_0',['get_ptr',['../structsring.html#a0dfc53cb80d94dc7f1a2eff3358bfbb9',1,'sring']]]
];
