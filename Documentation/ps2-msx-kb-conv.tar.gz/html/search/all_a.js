var searchData=
[
  ['kana_5fexti_0',['KANA_exti',['../system_8h.html#a08f80ac4b4fcf28aae3983feafd0f9bd',1,'KANA_exti():&#160;system.h'],['../system_01_07copy_011_08_8h.html#a08f80ac4b4fcf28aae3983feafd0f9bd',1,'KANA_exti():&#160;system (copy 1).h']]],
  ['kana_5fformer_1',['kana_former',['../ps2-msx-kb-conv_8cpp.html#a28cf21e78815d55daa24f19050cf2e37',1,'kana_former():&#160;ps2-msx-kb-conv.cpp'],['../ps2handl_8c.html#a28cf21e78815d55daa24f19050cf2e37',1,'kana_former():&#160;ps2handl.c']]],
  ['kana_5fpin_2',['KANA_PIN',['../system_01_07copy_011_08_8h.html#a725cc9e2f31b9338bca6748846a615a4',1,'KANA_PIN():&#160;system (copy 1).h'],['../system_8h.html#a725cc9e2f31b9338bca6748846a615a4',1,'KANA_PIN():&#160;system.h']]],
  ['kana_5fport_3',['KANA_PORT',['../system_01_07copy_011_08_8h.html#a20d1458d9b483309565c97f15407ef52',1,'KANA_PORT():&#160;system (copy 1).h'],['../system_8h.html#a20d1458d9b483309565c97f15407ef52',1,'KANA_PORT():&#160;system.h']]],
  ['kana_5fstate_4',['kana_state',['../ps2handl_8c.html#a9ae68f34760115b0307567b526b4ea04',1,'kana_state():&#160;ps2handl.c'],['../ps2-msx-kb-conv_8cpp.html#a9ae68f34760115b0307567b526b4ea04',1,'kana_state():&#160;ps2-msx-kb-conv.cpp']]],
  ['kb_5facknowledge_5',['KB_ACKNOWLEDGE',['../ps2handl_8c.html#a4313b4f2f9f9808fca38c53d77e811d4',1,'ps2handl.c']]],
  ['kb_5ferror_5fbat_6',['KB_ERROR_BAT',['../ps2handl_8c.html#a10f9483f089144b98ee98f50d7a12664',1,'ps2handl.c']]],
  ['kb_5ffirst_5fid_7',['KB_FIRST_ID',['../ps2handl_8c.html#a655be35ccbaa0c826f12c49eb545a7c6',1,'ps2handl.c']]],
  ['kb_5fsecond_5fid_8',['KB_SECOND_ID',['../ps2handl_8c.html#a2ca3d44507e4157b53a59abf915384e0',1,'ps2handl.c']]],
  ['kb_5fsuccessfull_5fbat_9',['KB_SUCCESSFULL_BAT',['../ps2handl_8c.html#a84f8523b86a340097989b86c38da57fb',1,'ps2handl.c']]],
  ['kbcomm_5fresend_10',['KBCOMM_RESEND',['../ps2handl_8c.html#afe708a0a24b5d6c79fb29b903cc695a6',1,'ps2handl.c']]],
  ['keyboard_5fcheck_5falive_11',['keyboard_check_alive',['../ps2handl_8c.html#aec6c85100b7c45b322e278b6c381cde2',1,'keyboard_check_alive(void):&#160;ps2handl.c'],['../ps2handl_8h.html#aec6c85100b7c45b322e278b6c381cde2',1,'keyboard_check_alive(void):&#160;ps2handl.c']]]
];
