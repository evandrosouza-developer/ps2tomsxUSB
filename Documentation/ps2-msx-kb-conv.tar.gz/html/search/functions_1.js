var searchData=
[
  ['available_5fmsx_5fdisp_5fkeys_5fqueue_5fbuffer_0',['available_msx_disp_keys_queue_buffer',['../classmsxmap.html#ac2a622675aac06fae13147e853364da9',1,'msxmap']]],
  ['available_5fps2_5fbyte_1',['available_ps2_byte',['../ps2handl_8c.html#a05ac9ef5a00a7316658d6d03036a6fbb',1,'ps2handl.c']]]
];
