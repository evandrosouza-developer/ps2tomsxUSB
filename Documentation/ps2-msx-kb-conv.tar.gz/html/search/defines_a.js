var searchData=
[
  ['len_5fserial_5fno_0',['LEN_SERIAL_No',['../system_8h.html#abebcaca178ac86656a87f2c3ee94fcb1',1,'system.h']]]
];
