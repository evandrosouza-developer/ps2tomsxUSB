var searchData=
[
  ['base_5fring_5fbuffer_5fsize_0',['BASE_RING_BUFFER_SIZE',['../system_01_07copy_011_08_8h.html#aaa991f7d0fe0a15baf96c8988bfcd564',1,'BASE_RING_BUFFER_SIZE():&#160;system (copy 1).h'],['../system_8h.html#aaa991f7d0fe0a15baf96c8988bfcd564',1,'BASE_RING_BUFFER_SIZE():&#160;system.h']]],
  ['base_5fring_5fbuffer_5fsz_5fpower_1',['BASE_RING_BUFFER_SZ_POWER',['../system_01_07copy_011_08_8h.html#aabd5f6a9cb3b50d58cb276818c5cf792',1,'BASE_RING_BUFFER_SZ_POWER():&#160;system (copy 1).h'],['../system_8h.html#aabd5f6a9cb3b50d58cb276818c5cf792',1,'BASE_RING_BUFFER_SZ_POWER():&#160;system.h']]],
  ['board_5fident_2',['BOARD_IDENT',['../usb__descriptors_8h.html#a209aaee6e9cf4f39cb1f575819284e6e',1,'usb_descriptors.h']]],
  ['bootmagic0_3',['BOOTMAGIC0',['../system_01_07copy_011_08_8h.html#aefe64de225ab9f9ed0f98e17adf34679',1,'BOOTMAGIC0():&#160;system (copy 1).h'],['../system_8h.html#aefe64de225ab9f9ed0f98e17adf34679',1,'BOOTMAGIC0():&#160;system.h']]],
  ['bootmagic1_4',['BOOTMAGIC1',['../system_01_07copy_011_08_8h.html#a9c7d020f7c05c18952aec4b920d4a273',1,'BOOTMAGIC1():&#160;system (copy 1).h'],['../system_8h.html#a9c7d020f7c05c18952aec4b920d4a273',1,'BOOTMAGIC1():&#160;system.h']]]
];
