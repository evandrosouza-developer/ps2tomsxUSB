var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvxy",
  1: "ms",
  2: "cdfghmprsuv",
  3: "_abcdefghikmprstuv",
  4: "_abcdefgklmnopstuxy",
  5: "eip",
  6: "eip",
  7: "abcdefghiklmnopqrstuxy",
  8: "cdhmpsu",
  9: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};

