var searchData=
[
  ['len_5fserial_5fno_0',['LEN_SERIAL_No',['../system_01_07copy_011_08_8h.html#abebcaca178ac86656a87f2c3ee94fcb1',1,'LEN_SERIAL_No():&#160;system (copy 1).h'],['../system_8h.html#abebcaca178ac86656a87f2c3ee94fcb1',1,'LEN_SERIAL_No():&#160;system.h']]]
];
