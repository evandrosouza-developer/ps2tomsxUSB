var searchData=
[
  ['database_20management_0',['Database Management',['../group__dbasemgt.html',1,'']]]
];
