var searchData=
[
  ['embedded_5fled_5fpin_0',['EMBEDDED_LED_PIN',['../system_01_07copy_011_08_8h.html#a8a80a78ab9618ca717871c4c64e8f75b',1,'EMBEDDED_LED_PIN():&#160;system (copy 1).h'],['../system_8h.html#a8a80a78ab9618ca717871c4c64e8f75b',1,'EMBEDDED_LED_PIN():&#160;system.h']]],
  ['embedded_5fled_5fport_1',['EMBEDDED_LED_PORT',['../system_01_07copy_011_08_8h.html#a15cc69ee8879655b9b8ea3b6ae2cc508',1,'EMBEDDED_LED_PORT():&#160;system (copy 1).h'],['../system_8h.html#a15cc69ee8879655b9b8ea3b6ae2cc508',1,'EMBEDDED_LED_PORT():&#160;system.h']]]
];
