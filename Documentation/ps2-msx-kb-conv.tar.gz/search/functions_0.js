var searchData=
[
  ['_5f_5fattribute_5f_5f_0',['__attribute__',['../database_8c.html#abde056554f7359992fdf374b7f749269',1,'database.c']]],
  ['_5fwrite_1',['_write',['../serial_8c.html#aa025a12d45f60c7d0eae249e61f0c7f9',1,'_write(int file, char *ptr, int len):&#160;serial.c'],['../serial_8h.html#aa025a12d45f60c7d0eae249e61f0c7f9',1,'_write(int file, char *ptr, int len):&#160;serial.c']]]
];
