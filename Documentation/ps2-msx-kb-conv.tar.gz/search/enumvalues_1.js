var searchData=
[
  ['intf_5fcon_5fcomm_0',['INTF_CON_COMM',['../system_8h.html#afda40464b8a42f9893f048d58bf4de92afdbc675c76f7ab498922fc251f6bdcb0',1,'system.h']]],
  ['intf_5fcon_5fdata_1',['INTF_CON_DATA',['../system_8h.html#afda40464b8a42f9893f048d58bf4de92ae1e59c6db5cb01a93e6cde790c9f518d',1,'system.h']]],
  ['intf_5fuart_5fcomm_2',['INTF_UART_COMM',['../system_8h.html#afda40464b8a42f9893f048d58bf4de92aa983723b24f1c20e69f0678319001696',1,'system.h']]],
  ['intf_5fuart_5fdata_3',['INTF_UART_DATA',['../system_8h.html#afda40464b8a42f9893f048d58bf4de92a069ce1a5bc9b38c11603bd5bb68807c8',1,'system.h']]]
];
