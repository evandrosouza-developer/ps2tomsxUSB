var searchData=
[
  ['keyboard_5fcheck_5falive_0',['keyboard_check_alive',['../ps2handl_8c.html#aec6c85100b7c45b322e278b6c381cde2',1,'keyboard_check_alive(void):&#160;ps2handl.c'],['../ps2handl_8h.html#aec6c85100b7c45b322e278b6c381cde2',1,'keyboard_check_alive(void):&#160;ps2handl.c']]]
];
