var searchData=
[
  ['otg_5ffs_5fdm_5fpin_0',['OTG_FS_DM_PIN',['../system_01_07copy_011_08_8h.html#ac650578ba563e1d32c47ed557bd1e93b',1,'system (copy 1).h']]],
  ['otg_5ffs_5fdm_5fport_1',['OTG_FS_DM_PORT',['../system_01_07copy_011_08_8h.html#a86365332bf523797c062a1976b711fcf',1,'system (copy 1).h']]],
  ['otg_5ffs_5fdp_5fpin_2',['OTG_FS_DP_PIN',['../system_01_07copy_011_08_8h.html#a587652f71fc142b3966937171e0b8ad4',1,'system (copy 1).h']]],
  ['otg_5ffs_5fdp_5fport_3',['OTG_FS_DP_PORT',['../system_01_07copy_011_08_8h.html#a38b7dd9e981c0ae5ddd1584d21173370',1,'system (copy 1).h']]]
];
