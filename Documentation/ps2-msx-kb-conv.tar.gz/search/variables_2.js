var searchData=
[
  ['base_5fof_5fdatabase_0',['base_of_database',['../dbasemgt_8c.html#adc15948440d15f8d0d7c8349b50540b4',1,'base_of_database():&#160;msxmap.cpp'],['../get__intelhex_8c.html#adc15948440d15f8d0d7c8349b50540b4',1,'base_of_database():&#160;msxmap.cpp'],['../msxmap_8cpp.html#a08b24d97cda105bac6a3e3ca38f2112c',1,'base_of_database():&#160;msxmap.cpp']]],
  ['buf_5fdma_5frx_1',['buf_dma_rx',['../serial_8c.html#af02d9f5207c626b542d5e8c6423e73e7',1,'serial.c']]],
  ['bufszmask_2',['bufSzMask',['../structs__pascal__string.html#aeabba46e6af39fdde6fce5f7145fc4d0',1,'s_pascal_string::bufSzMask()'],['../structsring.html#a42a673037b6b5850016922301a0e3f07',1,'sring::bufSzMask()']]]
];
