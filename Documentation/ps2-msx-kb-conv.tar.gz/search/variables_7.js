var searchData=
[
  ['get_5fptr_0',['get_ptr',['../structsring.html#aadbce4aba6c61dbac0f370a05f8a1564',1,'sring']]]
];
