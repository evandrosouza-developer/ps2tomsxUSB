var newlib__warning__fix_8h =
[
    [ "NEWLIB_WARNING_FIX_H", "newlib__warning__fix_8h.html#aca56800ced696236358cbeaa239b7ad4", null ],
    [ "_close", "newlib__warning__fix_8h.html#a036bc49a9f14455741940369aa888368", null ],
    [ "_getpid", "newlib__warning__fix_8h.html#a77c2639bd5388a6f48e28b3660efa0ca", null ],
    [ "_kill", "newlib__warning__fix_8h.html#ae47169369e6a23386a0d453c8b728f06", null ],
    [ "_lseek", "newlib__warning__fix_8h.html#aadb3a0af49d99b79debcee40c9d48127", null ],
    [ "_read", "newlib__warning__fix_8h.html#a12e573b08cd62fa793c682783eb2a6b1", null ]
];