var annotated_dup =
[
    [ "msxmap", "classmsxmap.html", "classmsxmap" ],
    [ "s_pascal_string", "structs__pascal__string.html", "structs__pascal__string" ],
    [ "sring", "structsring.html", "structsring" ]
];