var sys__timer_8h =
[
    [ "MAX_TICKS_KEYS", "sys__timer_8h.html#a923942053bdbf2ee12cb67b3f52e75f6", null ],
    [ "systick_setup", "sys__timer_8h.html#ad503852cf33facead172697e7995ab6b", null ]
];