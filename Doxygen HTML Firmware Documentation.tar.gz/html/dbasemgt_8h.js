var dbasemgt_8h =
[
    [ "database_setup", "dbasemgt_8h.html#a9dc517f60a7d86bd752ab7a18b7540a0", null ],
    [ "flash_rw", "dbasemgt_8h.html#aaeab188c8bc49c87db16cec1632d2c7b", null ]
];