var hr__timer_8h =
[
    [ "delay_usec", "hr__timer_8h.html#a5716d6ec15d35373021db6492e815eaf", null ],
    [ "prepares_capture", "hr__timer_8h.html#aff0a7dc5d67649581348027ef501e3a7", null ],
    [ "tim_hr_setup", "hr__timer_8h.html#a8ae961e30b547238f645ad27ec6f5b85", null ]
];