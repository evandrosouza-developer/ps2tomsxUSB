var searchData=
[
  ['kana_5fformer_0',['kana_former',['../ps2-msx-kb-conv_8cpp.html#a28cf21e78815d55daa24f19050cf2e37',1,'kana_former():&#160;ps2-msx-kb-conv.cpp'],['../ps2handl_8c.html#a28cf21e78815d55daa24f19050cf2e37',1,'kana_former():&#160;ps2handl.c']]],
  ['kana_5fstate_1',['kana_state',['../ps2-msx-kb-conv_8cpp.html#a9ae68f34760115b0307567b526b4ea04',1,'kana_state():&#160;ps2-msx-kb-conv.cpp'],['../ps2handl_8c.html#a9ae68f34760115b0307567b526b4ea04',1,'kana_state():&#160;ps2handl.c']]]
];
