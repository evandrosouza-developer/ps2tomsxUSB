var searchData=
[
  ['base_5fof_5fdatabase_0',['base_of_database',['../dbasemgt_8c.html#adc15948440d15f8d0d7c8349b50540b4',1,'base_of_database():&#160;msxmap.cpp'],['../get__intelhex_8c.html#adc15948440d15f8d0d7c8349b50540b4',1,'base_of_database():&#160;msxmap.cpp'],['../msxmap_8cpp.html#a08b24d97cda105bac6a3e3ca38f2112c',1,'base_of_database():&#160;msxmap.cpp']]],
  ['buf_5fdma_5frx_1',['buf_dma_rx',['../serial_8c.html#af02d9f5207c626b542d5e8c6423e73e7',1,'serial.c']]],
  ['bufszmask_2',['bufSzMask',['../structs__pascal__string.html#a0b5b7a3d67ef63f72e764fbd6ac36297',1,'s_pascal_string::bufSzMask()'],['../structsring.html#a644560aad45670bb7554bd47af34aacb',1,'sring::bufSzMask()']]]
];
