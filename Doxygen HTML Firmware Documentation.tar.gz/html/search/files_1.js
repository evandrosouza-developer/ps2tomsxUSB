var searchData=
[
  ['database_2ec_0',['database.c',['../database_8c.html',1,'']]],
  ['dbasemgt_2ec_1',['dbasemgt.c',['../dbasemgt_8c.html',1,'']]],
  ['dbasemgt_2eh_2',['dbasemgt.h',['../dbasemgt_8h.html',1,'']]]
];
