var searchData=
[
  ['y_5fdummy_0',['y_dummy',['../dbasemgt_8c.html#ac7b4cf552db7efc8d648908b2013b469',1,'y_dummy():&#160;msxmap.cpp'],['../msxmap_8cpp.html#ac7b4cf552db7efc8d648908b2013b469',1,'y_dummy():&#160;msxmap.cpp']]],
  ['y_5fxlat_5ftable_1',['Y_XLAT_TABLE',['../msxmap_8cpp.html#a26e610d8faf8ff61f06a5ddc4a3c7a4c',1,'msxmap.cpp']]]
];
