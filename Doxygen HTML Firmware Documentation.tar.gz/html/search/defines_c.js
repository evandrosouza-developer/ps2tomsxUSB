var searchData=
[
  ['n_5fdatabase_5fregisters_0',['N_DATABASE_REGISTERS',['../system_8h.html#ada3e1648d90b78cc8889adb245d120fb',1,'system.h']]],
  ['newlib_5fwarning_5ffix_5fh_1',['NEWLIB_WARNING_FIX_H',['../newlib__warning__fix_8h.html#aca56800ced696236358cbeaa239b7ad4',1,'newlib_warning_fix.h']]],
  ['nibble_2',['NIBBLE',['../msxmap_8cpp.html#a6d5eaeb40ae91c5fa9f9d865c6fb6610',1,'msxmap.cpp']]],
  ['num_5fdatabase_5fimg_3',['NUM_DATABASE_IMG',['../system_8h.html#a8f062372e2ff573d75386975db9255ba',1,'system.h']]],
  ['nvic_5ftim_5fhr_5firq_4',['NVIC_TIM_HR_IRQ',['../system_8h.html#af95e448eca350b38d427a9c9237ac1d2',1,'system.h']]],
  ['nvic_5fusart_5firq_5',['NVIC_USART_IRQ',['../system_8h.html#aff25a818ad4471ca2f2100ba4458e24d',1,'NVIC_USART_IRQ():&#160;system.h'],['../system_8h.html#aff25a818ad4471ca2f2100ba4458e24d',1,'NVIC_USART_IRQ():&#160;system.h']]]
];
