var searchData=
[
  ['database_5fsetup_0',['database_setup',['../dbasemgt_8c.html#a9dc517f60a7d86bd752ab7a18b7540a0',1,'database_setup(void):&#160;dbasemgt.c'],['../dbasemgt_8h.html#a9dc517f60a7d86bd752ab7a18b7540a0',1,'database_setup(void):&#160;dbasemgt.c']]],
  ['delay_5fusec_1',['delay_usec',['../hr__timer_8c.html#aca62fc87cbdabb84892de9b88b5a0a89',1,'delay_usec(uint32_t timer_peripheral, uint16_t usec, void next_step(void)):&#160;hr_timer.c'],['../hr__timer_8h.html#a5716d6ec15d35373021db6492e815eaf',1,'delay_usec(uint32_t timer_peripheral, uint16_t qusec, void next_step(void)):&#160;hr_timer.c']]],
  ['disable_5fusb_2',['disable_usb',['../cdcacm_8h.html#aece69c760bceda278c8c8fce8fcc38d2',1,'cdcacm.h']]],
  ['do_5fdma_5fusart_5ftx_5fring_3',['do_dma_usart_tx_ring',['../serial_8c.html#a0602b71dae2f607437c0ef26fd4cc19b',1,'do_dma_usart_tx_ring(uint16_t number_of_data):&#160;serial.c'],['../serial_8h.html#a0602b71dae2f607437c0ef26fd4cc19b',1,'do_dma_usart_tx_ring(uint16_t number_of_data):&#160;serial.c']]]
];
