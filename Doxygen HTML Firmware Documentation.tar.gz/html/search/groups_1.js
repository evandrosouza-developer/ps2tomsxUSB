var searchData=
[
  ['high_20resolution_20timer_0',['High Resolution Timer',['../group__hr__timer.html',1,'']]]
];
