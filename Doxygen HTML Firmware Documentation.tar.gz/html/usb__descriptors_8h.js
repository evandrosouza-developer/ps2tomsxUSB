var usb__descriptors_8h =
[
    [ "BOARD_IDENT", "usb__descriptors_8h.html#a209aaee6e9cf4f39cb1f575819284e6e", null ],
    [ "serial_no", "usb__descriptors_8h.html#aab387e785ff1846dbcb3847cdef84d9b", null ]
];