var cdcacm_8c =
[
    [ "enable_xon_xoff", "cdcacm_8c.html#a64d290bb0f3206115b1db9398859c634", null ],
    [ "ok_to_rx", "cdcacm_8c.html#a5238435d37669d56392b92df808bea90", null ],
    [ "uart_rx_ring", "cdcacm_8c.html#ab3cfba6e3084b56ab745ad3ea79caad6", null ],
    [ "uart_tx_ring", "cdcacm_8c.html#a77455825b1a5a17dd5b826c7a1e48e7f", null ],
    [ "xoff_condition", "cdcacm_8c.html#a0a9fe4593f99820a79ace1b5dc92a386", null ],
    [ "xon_condition", "cdcacm_8c.html#a5805c3f5abf93651befcd09329b76f53", null ],
    [ "xonoff_sendnow", "cdcacm_8c.html#a7981326d0b1e2f0be33a46a0d925fae1", null ]
];