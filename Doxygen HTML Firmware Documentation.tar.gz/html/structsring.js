var structsring =
[
    [ "bufSzMask", "structsring.html#a644560aad45670bb7554bd47af34aacb", null ],
    [ "data", "structsring.html#abe222f6d3581e7920dcad5306cc906a8", null ],
    [ "get_ptr", "structsring.html#a0dfc53cb80d94dc7f1a2eff3358bfbb9", null ],
    [ "put_ptr", "structsring.html#afd0b6d30bedaecf261d7f0abd2ed6a5e", null ]
];