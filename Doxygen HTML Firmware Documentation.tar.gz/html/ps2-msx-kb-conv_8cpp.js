var ps2_msx_kb_conv_8cpp =
[
    [ "DELAY_JHONSON", "ps2-msx-kb-conv_8cpp.html#a32fb2d830ed638a6a9a541ad71f95caf", null ],
    [ "end_of_code", "ps2-msx-kb-conv_8cpp.html#a3fa19eeb8f34f806cb667f6420e93b1f", null ],
    [ "main", "ps2-msx-kb-conv_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "caps_former", "ps2-msx-kb-conv_8cpp.html#aa5200769eeed925882c666ca83d2d89d", null ],
    [ "caps_state", "ps2-msx-kb-conv_8cpp.html#ac75b0345cc62ba3be0fdc0e6fe21ae3b", null ],
    [ "command_running", "ps2-msx-kb-conv_8cpp.html#acabda9b8575332a8933ea2562f2ee3f9", null ],
    [ "compatible_database", "ps2-msx-kb-conv_8cpp.html#a2b3dd091abf4bc5f05bd47816c4e94fb", null ],
    [ "do_next_keep_alive", "ps2-msx-kb-conv_8cpp.html#ab02d39a8348e208fee6bec56ae792dd8", null ],
    [ "formerscancode", "ps2-msx-kb-conv_8cpp.html#ae7b2e6cce8b88a31d33881c33fbeee10", null ],
    [ "kana_former", "ps2-msx-kb-conv_8cpp.html#a28cf21e78815d55daa24f19050cf2e37", null ],
    [ "kana_state", "ps2-msx-kb-conv_8cpp.html#a9ae68f34760115b0307567b526b4ea04", null ],
    [ "mount_scancode_OK", "ps2-msx-kb-conv_8cpp.html#a2824327df81870a386c0260059a99335", null ],
    [ "ps2_keyb_detected", "ps2-msx-kb-conv_8cpp.html#a5a43e74d9902058327ad9b9b2936bf96", null ],
    [ "ps2int_RX_bit_idx", "ps2-msx-kb-conv_8cpp.html#ab13c4515e9548f0da5ca8c85aafd2578", null ],
    [ "ps2numlockstate", "ps2-msx-kb-conv_8cpp.html#ab892f5e3c8e4ed273ee856cd9539e9bf", null ],
    [ "scancode", "ps2-msx-kb-conv_8cpp.html#a1e0609111324ff90e0050507b722e0a4", null ],
    [ "serial_no", "ps2-msx-kb-conv_8cpp.html#a0261a11afddf09458afa08342d73bd94", null ],
    [ "systicks", "ps2-msx-kb-conv_8cpp.html#ab9553772b4f58c24099f93aefe737100", null ],
    [ "update_ps2_leds", "ps2-msx-kb-conv_8cpp.html#af0cf6a2753755fc3cf776458e2dbd196", null ]
];