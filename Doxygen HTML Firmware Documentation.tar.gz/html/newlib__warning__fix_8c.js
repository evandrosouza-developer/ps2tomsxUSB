var newlib__warning__fix_8c =
[
    [ "_close", "newlib__warning__fix_8c.html#a89d03692881c98197f1168cfe274d3f6", null ],
    [ "_getpid", "newlib__warning__fix_8c.html#af7d8308a3080c4f341abe2237594167e", null ],
    [ "_kill", "newlib__warning__fix_8c.html#ae4f4984cff982459b6a165f56e86a1cb", null ],
    [ "_lseek", "newlib__warning__fix_8c.html#ab3fca177137328e6e5d0552bea072a4d", null ],
    [ "_read", "newlib__warning__fix_8c.html#a18b19ea19599213612131fc601786064", null ]
];