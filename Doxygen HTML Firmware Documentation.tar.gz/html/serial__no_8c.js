var serial__no_8c =
[
    [ "OFFSET", "serial__no_8c.html#a21005f9f4e2ce7597c5eb4351816d7e2", null ],
    [ "serialno_read", "serial__no_8c.html#a7305f05eb340f05b437a8483298aad75", null ],
    [ "serial_no", "serial__no_8c.html#a0261a11afddf09458afa08342d73bd94", null ]
];