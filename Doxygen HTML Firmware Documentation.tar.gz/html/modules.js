var modules =
[
    [ "USB_Group", "group__USB.html", null ],
    [ "High Resolution Timer", "group__hr__timer.html", null ],
    [ "MSX Interface Translator", "group__msxmap.html", null ],
    [ "PS/2 Keyboard Interface Handler", "group__ps2handl.html", null ],
    [ "USART_Group", "group__USART.html", null ],
    [ "Read_Serial_Number", "group__serial__no.html", null ],
    [ "Special Function Handlers", "group__special__function__handlers.html", null ],
    [ "System Timer and smooth typing", "group__sys__timer.html", null ],
    [ "Main", "group__Manager__group.html", null ],
    [ "Database Management", "group__dbasemgt.html", null ]
];