var structs__pascal__string =
[
    [ "bufSzMask", "structs__pascal__string.html#a0b5b7a3d67ef63f72e764fbd6ac36297", null ],
    [ "data", "structs__pascal__string.html#abe222f6d3581e7920dcad5306cc906a8", null ],
    [ "str_len", "structs__pascal__string.html#a51f8e5d494f30807eab1cb2d29e2015a", null ]
];